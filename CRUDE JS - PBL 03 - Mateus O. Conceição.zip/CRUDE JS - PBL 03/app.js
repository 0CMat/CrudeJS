
//Importando para o projeto (dentro do arquivo app.js)
    const express = require('express');
    const bodyParser = require('body-parser');
    const mysql = require('mysql');
    const handlebars = require('express-handlebars');
    const { stat } = require('fs');
    const { userInfo } = require('os');

    const app = express();
//configurando o body-parser
    const urlencodeParser = bodyParser.urlencoded({extended: false});

// //configurando com o banco de dadinhos
//     const sql = mysql.createConnection({
//         host:'localhost',
//         user:'root',
//         password:'654321pk',
//         port:3306
//     });    

//iniciando o servidor http
    app.listen(8080,function(req,res){
        console.log('Servidor funcionando!');
    });


//configurando tamplate(handlebars)
    app.engine("handlebars", handlebars({defaultLayout:'main'}));
    app.set('view engine', 'handlebars');

//configurando css, js, img
    app.use('/CSS', express.static('CSS'));
    app.use('/JS', express.static('js'));
    app.use('/IMG', express.static('img'));    

//rotas e templates
    app.get('/',function(req,res){
        //res.send("Página Incial");
        //res.sendfile(__dirnme +"/teste.html");
        res.render('index');
    });

    app.get('/inserir',function(req,res){
        res.render('inserir');
    });

    app.get('/listar',function(req,res){
        res.render('listar');
    });

    app.get('/sobre',function(req,res){
        res.render('sobre');
    });
